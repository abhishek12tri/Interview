from langchain.document_loaders import JSONLoader

import json
from pathlib import Path
from pprint import pprint
import os


# all_data =  {"image": {"creation_timestamp": 1675549016, "uri": "image_of_the_chat.jpg"},
#      "is_still_participant": True,
#      "joinable_mode": {"link": "", "mode": 1},
#      "magic_words": [],
#      "messages": [{"content": "Bye!",
#                    "sender_name": "User 2",
#                    "timestamp_ms": 1675597571851},
#                   {"content": "Oh no worries! Bye",
#                    "sender_name": "User 1",
#                    "timestamp_ms": 1675597435669},
#                   {"content": "No Im sorry it was my mistake, the blue one is not "
#                               "for sale",
#                    "sender_name": "User 2",
#                    "timestamp_ms": 1675596277579},
#                   {"content": "I thought you were selling the blue one!",
#                    "sender_name": "User 1",
#                    "timestamp_ms": 1675595140251},
#                   {"content": "Im not interested in this bag. Im interested in the "
#                               "blue one!",
#                    "sender_name": "User 1",
#                    "timestamp_ms": 1675595109305},
#                   {"content": "Here is $129",
#                    "sender_name": "User 2",
#                    "timestamp_ms": 1675595068468},
#                   {"photos": [{"creation_timestamp": 1675595059,
#                                "uri": "url_of_some_picture.jpg"}],
#                    "sender_name": "User 2",
#                    "timestamp_ms": 1675595060730},
#                   {"content": "Online is at least $100",
#                    "sender_name": "User 2",
#                    "timestamp_ms": 1675595045152},
#                   {"content": "How much do you want?",
#                    "sender_name": "User 1",
#                    "timestamp_ms": 1675594799696},
#                   {"content": "Goodmorning! $50 is too low.",
#                    "sender_name": "User 2",
#                    "timestamp_ms": 1675577876645},
#                   {"content": "Hi! Im interested in your bag. Im offering $50. Let "
#                               "me know if you are interested. Thanks!",
#                    "sender_name": "User 1",
#                    "timestamp_ms": 1675549022673}],
#      "participants": [{"name": "User 1"}, {"name": "User 2"}],
#      "thread_path": "inbox/User 1 and User 2 chat",
#      "title": "User 1 and User 2 chat"}

# print(all_data)
# print(os.listdir("datasets"))

# with open("datasets/sample_file.json", "w") as file:
#     json.dump(all_data, file)


file_path='datasets/sample_file.json'
# data = json.loads(Path(file_path).read_text())

# pprint(data)

loader = JSONLoader(
    file_path=file_path,
    jq_schema='.messages[].content')

data = loader.load()

pprint(data)

