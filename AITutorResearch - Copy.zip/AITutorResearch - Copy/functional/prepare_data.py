import os
import csv
import pandas as pd

def prepare_LevelsContent(file_paths):
    try:
        dataframe = pd.read_excel(file_paths["source"])

        if os.path.isfile(file_paths["destination"]):
            os.remove(file_paths["destination"])

        with open(file_paths["destination"], "a+") as f:
            for index, row in dataframe.iterrows():
                single_context = row["ContextData"]
                f.write(single_context+"\n\n")
                
    except Exception as e:
        raise e
    
def prepare_knowledge_base(file_paths):
    try:
        with open(file_paths["source"]) as file_obj:
            reader_obj = csv.reader(file_obj)

            if os.path.isfile(file_paths["destination"]):
                os.remove(file_paths["destination"])
                
            with open(file_paths["destination"], "a+") as f:

                for row in reader_obj:
                    if row[0].isdigit() and int(row[0]) > 78 and row[4].strip() != "":
                        f.write(row[4]+"\n\n")
                        
    except Exception as e:
        raise e

if __name__ == "__main__":
    raw_path = "datasets"
    doc_path = "source_documents"

    file_paths = {
        "source": os.path.join(raw_path, "LevelsContent.xlsx"),
        "destination": os.path.join(doc_path, "LevelsContent.txt")
    }
    # prepare_LevelsContent(file_paths)
    file_paths = {
        "source": os.path.join(raw_path, "knowledge_base.csv"),
        "destination": os.path.join(doc_path, "knowledge_base.txt")
    }
    prepare_knowledge_base(file_paths)