import os
import sys
import json
import glob
import re
#import boto3

class Helper:
    def __init__(self) -> None:
        self.argument_file = "_tmp/arguments.json"
        self.module_name_path = "./datasets/level_*.txt"
        self.bucket_name = "hailabs-dev-data"
        self.clean_delimiters = 'Question:|"Explanation:|User:|Expected response:'
        #self.s3 = boto3.resource("s3")

    def make_local_dirs(self, file_path):
        """Make directories in local if not avail."""
        try:
            if not os.path.exists(file_path):
                os.makedirs(file_path)
        except Exception as e:
            raise e
        
    def write_command_line_args(self):
        """Write argument into the file."""
        try:
            file_path = os.path.dirname(self.argument_file)
            self.make_local_dirs(file_path)
            with open(self.argument_file, 'w') as f:
                f.write(json.dumps(sys.argv))
        except Exception as e:
            raise e
        
    def read_saved_args(self):
        """Read saved arguments."""
        try:
            with open(self.argument_file, "r") as f:
                return json.loads(f.read())
        except Exception as e:
            raise e
        
    def load_module_names(self):
        try:
            files = glob.glob(self.module_name_path, recursive = True)
            res = {}
            for each_file in files:
                with open(each_file, 'r') as f:   
                    data = json.load(f)
                    res = {**res, **data}

            return res
        except Exception as e:
            raise e
    
    def download_s3_files(self, s3_path, local_path):
        """Download from production S3."""
        self.s3.Bucket(self.bucket_name).download_file(s3_path, local_path)

    def test_cleaning(self, response):
        resp_split = response.split("\n")
        load_resp = "\n".join([each_split.strip() for each_split in resp_split if each_split.strip() != ""])

        res = re.split(self.clean_delimiters, load_resp)
                                                    
        if res[0].strip()!="":
            filter_response = res[0].strip()
        else:
            filter_response = "".join(res)

        print(filter_response)
        return filter_response
