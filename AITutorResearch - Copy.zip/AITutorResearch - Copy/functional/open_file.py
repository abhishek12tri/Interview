# python code to open the json file levels.json
import os
import re
import json
from pprint import pprint
import json
from typing import List
from langchain.docstore.document import Document
# from helper import Helper

import sys
from langchain.document_loaders import (
    PyMuPDFLoader
)
new_encoding = 'utf-8'
worksheet_dir = ""

LOADER_MAPPING = {
    ".pdf": (PyMuPDFLoader, {})
}
# helper = Helper()

#funtion to write data to a text file make sure new data is updated and file is closed after writingthe data
def write_to_file(dest_filename, data):
    try:
        with open(dest_filename, 'a', encoding="utf8") as f:
            f.write(str(data))
            f.write('\n')
            f.close()
    except Exception as e:
        print("-"*30)
        print(dest_filename)
        print(data)
        raise e

def read_raw_file(raw_file_name):
    try:
        with open(raw_file_name) as f:
            levels = json.load(f)
    except UnicodeDecodeError:
        """Error in Windows"""
        with open(raw_file_name, 'r', encoding="utf8") as f:
            levels = json.load(f)
    
    except Exception as e:
        raise e
    return levels

def load_single_document(file_path: str) -> List[Document]:
    ext = "." + file_path.rsplit(".", 1)[-1].lower()
    if ext in LOADER_MAPPING:
        loader_class, loader_args = LOADER_MAPPING[ext]
        loader = loader_class(file_path, **loader_args)
        return loader.load()

def manage_each_level(single_level, level_filename, modular=False):

    if not modular:
        dest_filename = level_filename
        if os.path.exists(dest_filename):
            os.remove(dest_filename)
    level_title= single_level['title']
    level_descriotion = single_level['description']
    level_learnig_objectives = " ".join(single_level['learning_objectives']).strip()
    level_index = str(single_level["order_no"])

    level_info = "Level: "+level_index
    level_info += "\n" + "Title: " + level_title
    level_info += "\n" + "Description: " + level_descriotion
    level_info += "\n" + "Learnig Objectives: " + level_learnig_objectives
    level_info += "\n"
    if not modular:
        write_to_file(dest_filename, level_info)

    module_names ={}

    if "pathways" in single_level:
        for pathway in single_level['pathways']:
            pathway_title = pathway['title']
            pathway_description = pathway['description']
            pathway_learning_objectives = pathway['learning_objectives'] if type(pathway['learning_objectives']) == None.__class__ else " ".join(pathway['learning_objectives'])
            pathway_index = str(pathway['order_no'])

            print(pathway_title, pathway_learning_objectives)

            pathway_info =  "Level: "+level_index+", Pathway: "+ pathway_index
            pathway_info += "\n" + "Title: " +pathway_title
            pathway_info += "\n" + "Description: " +pathway_description
            if type(pathway_learning_objectives) != None.__class__:
                pathway_info += "\n" + "Learnig Objectives: " +pathway_learning_objectives
            pathway_info += "\n"
            

            if not modular:
                write_to_file(dest_filename, pathway_info)

            for module in pathway['modules']:
                module_title = module['title']
                module_description = module['description']
                module_learning_objectives = module['learning_objectives'] if type(module['learning_objectives']) == None.__class__ else " ".join(module['learning_objectives'])
                module_index = str(module["order_no"])
                
                module_info = "Level: "+level_index+", Pathway: "+ pathway_index+", Module: "+module_index
                module_info += "\n" + "Title: " +module_title
                module_info += "\n" + "Description: " +module_description
                
                if type(module_learning_objectives) != None.__class__:
                    module_info += "\n" + "Learning Objective: " +module_learning_objectives

                """Update the destination filename for modular"""
                if modular:
                    splitted = level_filename.rsplit(".", 1)
                    dest_filename = "".join(splitted[:-1])+"_"+pathway_index+"_"+module_index+"."+splitted[-1]
                    if os.path.exists(dest_filename):
                        os.remove(dest_filename)
                        
                write_to_file(dest_filename, module_info)

                module_names[level_index+"_"+pathway_index+"_"+module_index] = module_title
                # print(module_description)
                # print(module_learning_objectives)
                variables = {
                    "{{!user_userName}}": "",
                    "{{!level_index}}": level_index,
                    "{{!pathway_title}}": pathway_title,
                    "{{!module_title}}": module_title,
                    "{{!module_description}}": module_description,
                    "{{!module_index}}": module_index,
                    "  ": " "
                }
                for data in module['module_data']:
                    for key, value in data.items():
                        if value is not None and isinstance(value, int)==False:

                            """If key is text, only extract the description."""
                            if key == "text" or key == "custom_module" or key == "video":
                                for each_text in value:
                                    
                                    text_title = each_text['title']
                                    text_desc = each_text['description']
                                    for to_replace, replacement in variables.items():
                                        text_title = text_title.replace(to_replace, replacement)
                                        text_desc = text_desc.replace(to_replace, replacement)

                                    discard_text_messages = [
                                        "Congratulations!!!",
                                        "Your project has been submitted for evaluation!"
                                    ]
                                    if text_title not in discard_text_messages:
                                        # Your project has been submitted for evaluation!
                                        extra_info = ""#.join(key.split("_")).title()
                                        extra_info += text_title
                                        extra_info += "\n" + text_desc
                                        extra_info += "\n"
                                        write_to_file(dest_filename, extra_info)
                                    
                            elif(key == "flashcard_contents"):
                                for each_flash in value:
                                    flash_title = each_flash["title"]
                                    flash_description = each_flash["description"]
                                    sequence = ["textone", "texttwo", "textthree", "textfour"]

                                    extra_info = 'Flashcard Contents'
                                    extra_info += "\n" + flash_title
                                    extra_info += "\n" + flash_description
                                    
                                    for each_detail in each_flash["details"]:
                                        detail_text = ""
                                        for seq in sequence:
                                            if seq in each_detail:
                                                detail_text+=each_detail[seq]+"\n"
                                        
                                        extra_info += "\n" + detail_text
                                    extra_info += "\n"
                                    write_to_file(dest_filename, extra_info)

                            elif(key == "quiz"):
                                for quiz_coll in value:
                                    quiz_title = quiz_coll["title"]
                                    quiz_desc = quiz_coll["description"]

                                    extra_info = 'Quiz Title: '+ quiz_title
                                    extra_info += "\n" + quiz_desc + "\n"
                                    for each_quiz in quiz_coll["questions"]:
                                        question = each_quiz["title"]
                                        correct = each_quiz["correctanswermessage"]
                                        wrong = each_quiz["wronganswermessage"]

                                        extra_info += "\nQuestion: " + question 

                                        if "options" in each_quiz:
                                            correct_ans = ""
                                            for each_option in each_quiz["options"]:
                                                if each_option["iscorrect"] == True:
                                                     correct_ans = each_option["option"]
                                            if correct_ans.strip() == 'All of the above':
                                                correct_ans=""
                                                for each_option in each_quiz["options"]:
                                                    if each_option["iscorrect"] != True:
                                                        correct_ans += each_option["option"]
                                            elif("Both Option 1 and Option 2" in correct_ans.strip()):
                                                correct_ans=each_quiz["options"][0]["option"]+", "
                                                correct_ans+=each_quiz["options"][1]["option"]
                                                
                                                
                                            extra_info += "\nAnswer: " + correct_ans+"\n"

                                        extra_info += correct+"\n"
                                        extra_info += wrong+"\n"
                                        # quiz_title, quiz_desc, question, correct, wrong
                                    extra_info += "\n"

                                    for to_replace, replacement in variables.items():
                                        extra_info = extra_info.replace(to_replace, replacement)
                                        
                                    write_to_file(dest_filename, extra_info)

                            elif(key == "project"):
                                for each_project in value:
                                    project_title = each_project["title"]

                                    project_desc = each_project["description"]
                                    project_desc += "\n" + each_project["details"]["develop"]["description"]
                                    project_desc += "\n" + each_project["details"]["intro"]["description"]
                                    
                                    project_desc += "\n" + each_project["details"]["develop"]["message"]
                                    project_desc += "\n" + "Once you submit the project, please look for notifications for feedback and score"

                                    if "algorithm" in each_project["details"]["data"]:
                                        project_desc += "\n" + "Algorithm used: "+each_project["details"]["data"]["algorithm"]
                                        project_desc += "\n" + each_project["details"]["data"]["title"]
                                        project_desc += "\n" + each_project["details"]["data"]["insufficientmessage"]
                                        project_desc += "\n" + "If training accuracy is more than "+ each_project["details"]["train"]["besttrainmessagelimit"] + " " + each_project["details"]["train"]["besttrainmessage"] 
                                        project_desc += "\n" + "If training accuracy is more than "+ each_project["details"]["train"]["goodtrainmessagelimit"] + " " + each_project["details"]["train"]["goodtrainmessage"]
                                        project_desc += "\n" + "If low training accuracy then " + each_project["details"]["train"]["badretrainmessage"]
                                        project_desc += "\n" + each_project["details"]["try"]["predictmessagewithpercentage"]

                                    extra_info = 'Project Title: '+ project_title
                                    extra_info +=  "\n" + project_desc
                                    extra_info += "\n"
                                    write_to_file(dest_filename, extra_info)

                                    if modular:
                                        worksheet_src = "./datasets"
                                        worksheet_file = ""

                                        if "develop" in each_project["details"] and "worksheet" in each_project["details"]["develop"]:
                                            worksheet_file = each_project["details"]["develop"]["worksheet"]
                                        elif "data" in each_project["details"] and "worksheet" in each_project["details"]["data"]:
                                            worksheet_file = each_project["details"]["data"]["worksheet"]

                                        if worksheet_file.strip() != "":
                                            worksheet_local = os.path.join(worksheet_src, worksheet_file)

                                            if not os.path.exists(worksheet_local):
                                                s3_file = os.path.join("resources/documents/pdf", worksheet_file)
                                                print("Downloading file "+worksheet_local )
                                                helper.download_s3_files(s3_file, worksheet_local)

                                            if os.path.exists(worksheet_local):
                                                loaded_doc = load_single_document(worksheet_local)
                                                complete_doc = ""
                                                for each_doc in loaded_doc:
                                                    load_doc = each_doc.page_content
                                                    # load_doc = load_doc.replace("\n\n", "\n")
                                                    # load_doc = load_doc.replace("\n \n", "\n")
                                                    doc_split = load_doc.split("\n")
                                                    load_doc = "\n".join([each_split for each_split in doc_split if each_split.strip() != ""])+"\n\n"
                                                    complete_doc += load_doc
                                                write_to_file(dest_filename, complete_doc)
                                            else:
                                                print("PDF Not found")

    
    if "module" not in sys.argv: 
        file_name = "./datasets/level_"+level_index+"_module.txt"
        if os.path.exists(file_name):
            os.remove(file_name)
        write_to_file(file_name, json.dumps(module_names, indent = 4) )

    return False

    for level in levels:
        # level = levels[0]
        print(level)
        break

        level_title= level['title']
        level_descriotion = level['description']
        level_learnig_objectives = level['learning_objectives']
        # print all those vaiables
        # write all the above varialbles of levels to file
        write_to_file(level_title)
        write_to_file(level_descriotion)
        write_to_file(level_learnig_objectives)
        for pathway in level['pathways']:
            pathway_title = pathway['title']
            pathway_description = pathway['description']
            pathway_learning_objectives = pathway['learning_objectives']
            # write all values to file
            write_to_file(str("pathway_title")+ " " +pathway_title)
            write_to_file(str("pathway_description")+ " " +pathway_description)
            write_to_file(str("pathway_learning_objectives")+ " " +str(pathway_learning_objectives))
            # print all those vaiables
            for module in pathway['modules']:
                module_title = module['title']
                module_description = module['description']
                module_learning_objectives = module['learning_objectives']
                #write all data to files    
                write_to_file(str("module_title")+" "+module_title)
                write_to_file(str("module_description")+" "+module_description)
                write_to_file(str("module_learning_objectives")+" "+str(module_learning_objectives))


                for data in module['module_data']:
                    # iterate to get values for keys that are not null and then write data to file
                    for key, value in data.items():
                        # check if the value is not null also check if the value is not a integer
                        if value is not None and isinstance(value, int)==False:
                            write_to_file(str(key)+" "+str(value))
                            #write a next line to file

        write_to_file('\n')

                        # print(value) 


if __name__ == "__main__":
    raw_file_name = './datasets/levels.json'
    levels = read_raw_file(raw_file_name)

    modular = False
    file_dir = "./source_documents/"
    if "module" in sys.argv:
        print("Saving files in modular fashion...")
        file_dir = "./modular_documents"
        modular = True

    if not os.path.exists(file_dir):
        os.makedirs(file_dir)

    for each_level in levels:
        level_filename = f"{file_dir}/level_"+str(each_level["order_no"])+".txt"
        manage_each_level(each_level, level_filename, modular)
        

#how to check if a value is a integer
# if isinstance(value, int):

# pathways = level['pathways']


# write a code to extract the data from the json file make sure all the data is extracted from all the keys even if its a nested dictionaries and also some keys will have list of dictionaries so make sure you extract all the data from the list of dictionaries as well.
# print the extracted data


print()
# pathways = level['pathways']
# # write data to a text file
# with open('./test_data/extracted_data.txt', 'w') as f:
#     f.write(str(pathways))


