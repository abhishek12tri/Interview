#numexpr==2.8.5


import json
import csv
import re
import mlflow
import requests
from ingest import load_single_document
from pprint import pprint
import pandas as pd
from rouge_score import rouge_scorer
from functional.open_file import read_raw_file

csv_data = "datasets/FAQ.csv"
quiz_data = "datasets/Quiz.csv"

def parapare_qa():
    raw = "source_documents/FAQ.txt"
    docs = load_single_document(raw)
    with open(csv_data, 'a', newline='') as csvfile:
        logwriter = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        index = 1
        for each_doc in docs:
            req_data = each_doc.page_content.split("\n")
            req_data = [each_sent for each_sent in req_data if each_sent.strip()!="" and "?" in each_sent]
            for term_doc in req_data:
                each_seq = term_doc.split("?")
                logwriter.writerow([index, each_seq[0]+"?".strip(), each_seq[1].strip(), '', ''])
                index+=1

def parapare_quiz():
    raw = "datasets/levels.json"
    levels = read_raw_file(raw)

    index = 1
    with open(quiz_data, 'w', newline='') as csvfile:
        logwriter = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        logwriter.writerow(["", "Level", "Pathay", "Module", "Question", "Result", "Response"])
        for single_level in levels:
            level_index = str(single_level["order_no"])
            if "pathways" in single_level:
                for pathway in single_level['pathways']:
                    pathway_index = str(pathway['order_no'])
                    for module in pathway['modules']:
                        module_index = str(module["order_no"])
                        for data in module['module_data']:
                            for key, value in data.items():
                                if value is not None and isinstance(value, int)==False:
                                    if(key == "quiz"):
                                        for quiz_coll in value:
                                            
                                            for each_quiz in quiz_coll["questions"]:
                                                question = each_quiz["title"]
                                                # print("Question: ", question) 
                                                
                                                if "options" in each_quiz:
                                                    correct_ans = ""
                                                    for each_option in each_quiz["options"]:
                                                        if each_option["iscorrect"] == True:
                                                            correct_ans = each_option["option"]

                                                    if correct_ans.strip() == 'All of the above':
                                                        correct_ans=""
                                                        for each_option in each_quiz["options"]:
                                                            if each_option["iscorrect"] != True:
                                                                correct_ans += each_option["option"]
                                                    elif("Both Option 1 and Option 2" in correct_ans.strip()):
                                                        correct_ans=each_quiz["options"][0]["option"]+", "
                                                        correct_ans+=each_quiz["options"][1]["option"]

                                            
                                                # print("Correct: ", correct_ans)
                                                logwriter.writerow([index, level_index, pathway_index, module_index, question.strip(), correct_ans.strip()])
                                                index+=1
                                            #print()


def read_data(data_file):
    all_info = []
    with open(data_file) as file_obj:
        reader_obj = csv.reader(file_obj)
        for row in reader_obj:
            all_info.append(row)
    return all_info

def get_responses(all_info, data_to_use):
    # url = 'http://localhost:8002/hailabs/get-response'
    url = 'http://localhost:8002/ai-tutor/get-response'

    
    with open(data_to_use, 'w', newline='') as csvfile:
        logwriter = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        logwriter.writerow(all_info[0])
        index = 1
        print(len(all_info))

        """Faq"""
        # for row in all_info[1:]:
        #     question = row[1]

        #     """For AI Tutor responses"""
        #     myobj = {
        #         'message': question
        #     }

        #     x = requests.post(url, json = myobj)
        #     print( x.json())
        #     result = x.json()["result"]
        #     time = x.json()["time"]
        #     print("-"*49)
        #     logwriter.writerow([row[0], row[1], row[2], row[3], row[4], row[5], result.strip(), time])
        #     index+=1
        #     print(result)

        """Quiz"""
        for row in all_info[1:]:
            question = row[4]

            """For AI Tutor responses"""
            myobj = {
                "level": row[1],
                "pathway": row[2],
                "module": row[3],
                'message': question
            }

            x = requests.post(url, json = myobj)
            print( x.json())
            result = x.json()["result"]
            time = x.json()["time"]
            print("-"*49)
            row.extend([result, time])

            logwriter.writerow(row)
            print(result)
    
    # file = open('items.txt','w')
    # for item in all_res:
    #     file.write(item+"\n")
    # file.close()


def find_rogue_score(file, all_info):
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rougeL'], use_stemmer=True)

    # with open(file, 'w', newline='') as csvfile:
    #     logwriter = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
    #     logwriter.writerow(all_info[0])

    #     for row in all_info[1:]:
    #         response = row[16].strip()
    #         resp_split = response.split("\n")
    #         load_resp = "\n".join([each_split.strip() for each_split in resp_split if each_split.strip() != ""])

    #         delimiters = 'Question:|"Explanation:|User:|Expected response:'

    #         res = re.split(delimiters, load_resp)
                                                        
    #         if res[0].strip()!="":
    #             filter_response = res[0].strip()
    #         else:
    #             filter_response = "".join(res)

    #         row[16] = filter_response
    #         logwriter.writerow(row)

    with open(file, 'w', newline='') as csvfile:
        logwriter = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        logwriter.writerow(all_info[0])
        for row in all_info[1:]:

            scores = scorer.score(row[5], row[16])
            row.extend([scores["rougeL"].precision, scores["rougeL"].recall, scores["rougeL"].fmeasure])
            logwriter.writerow(row)
            # print(scores["rouge1"])# scores["rougeL"].precision , scores["rougeL"].fmeasure
            print(scores["rougeL"].precision, scores["rougeL"].recall, scores["rougeL"].fmeasure)# scores["rougeL"].precision , scores["rougeL"].fmeasure



if __name__ ==  "__main__":
    # quiz_data csv_data
    data_to_use = quiz_data
    # parapare_qa()
    # parapare_quiz()
    all_info = read_data(data_to_use)
    # print(all_info)
    # get_responses(all_info, data_to_use)
    find_rogue_score(data_to_use, all_info)
    
    # with open(data_to_use, 'w', newline='') as csvfile:
    #     logwriter = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
    #     logwriter.writerow(all_info[0])

    
    #     for each_q in all_info[1:]:
    #         datatat =  eval(each_q[0])
    #         logwriter.writerow(datatat)
