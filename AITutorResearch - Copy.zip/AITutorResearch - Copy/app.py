from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from functional.helper import Helper
from pydantic import BaseModel
from typing import Union, Optional
from privateGPT import qa_load_model, get_response_from_qa, get_response_for_ai_tutor
from ingest import prapare_data

app = FastAPI()

# Write sys args in file to use in rasa arguments shell
Helper().write_command_line_args()
module_names = Helper().load_module_names()

"""Define server API Policy"""
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class UserData(BaseModel):
    message: str

class TutorData(BaseModel):
    level: Optional[str]
    pathway: Optional[str]
    module: Optional[str]
    message: str

"""Basic Test API"""
@app.get("/", tags=["Root"])
async def root():
    return {"message": "Hello World"}


qa_model = qa_load_model()

helper = Helper()
@app.post("/hailabs/get-response", tags=["HAILabs"])
async def get_response(user_data: UserData):
    message = user_data.message.strip()
    model_resp = get_response_from_qa(qa_model, message)
    result = model_resp["result"]
    model_resp["result"] = helper.test_cleaning(result)
    return model_resp


@app.post("/hailabs/prepare-data", tags=["HAILabs"])
async def prapare_DB():
    try:
        prapare_data()
        return {"status": "Saved Successfully"}
    except Exception as e:
        raise e
    
@app.post("/ai-tutor/get-response", tags=["AI Tutor"])
async def ai_tutor_response(tutor_data: TutorData):
    message = tutor_data.message.strip()
    level = tutor_data.level
    pathway = tutor_data.pathway
    module = tutor_data.module

    
    if level != None and pathway != None and module != None:
        current_module = ""
        module_key = level+"_"+pathway+"_"+module
        if module_key in module_names:
            current_module = module_names[module_key]
            
            model_resp = get_response_for_ai_tutor(message, level, pathway, module, current_module)
            result = model_resp["result"]
            model_resp["result"] = helper.test_cleaning(result)
            return model_resp
    
    model_resp = get_response_from_qa(qa_model, message)
    result = model_resp["result"]
    model_resp["result"] = helper.test_cleaning(result)
    return model_resp
        