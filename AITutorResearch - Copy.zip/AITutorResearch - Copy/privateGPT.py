#!/usr/bin/env python3
from dotenv import load_dotenv
from langchain.chains import RetrievalQA
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.vectorstores import Chroma
from langchain.llms import LlamaCpp # , GPT4All
from langchain.chains.question_answering import load_qa_chain
from langchain.retrievers.merger_retriever import MergerRetriever
# from langchain.memory import ConversationBufferMemory, ConversationSummaryMemory, ConversationBufferWindowMemory
# from langchain.chains import ConversationSummaryMemory
import os
import argparse
import time
from typing import Callable
from langchain.prompts import StringPromptTemplate
# from langchain.document import Document

#from langchain.chains.retrieval_qa.prompt import StringPromptTemplate


load_dotenv()

embeddings_model_name = os.environ.get("EMBEDDINGS_MODEL_NAME")
general_directory = os.environ.get('PERSIST_DIRECTORY')
modular_directory = os.environ.get('MODULAR_DIRECTORY')
target_source_chunks = int(os.environ.get('TARGET_SOURCE_CHUNKS',4))

# GPT4All
model_type = os.environ.get('MODEL_TYPE')
model_path = os.environ.get('MODEL_PATH')
model_n_ctx = os.environ.get('MODEL_N_CTX')
max_tokens = os.environ.get('MAX_TOKENS')
model_n_batch = int(os.environ.get('MODEL_N_BATCH',8))
use_mlock = os.environ.get('USE_MLOCK')
use_mmap = os.environ.get('USE_MMAP')
temperature = os.environ.get('TEMPERATURE')
mongo_uri = os.environ.get('MONGO_URI')
mongo_db = os.environ.get('DATABASE')
mongo_coll = os.environ.get('COLLECTION')
# memory=ConversationBufferMemory(return_messages=True)

from langchain.prompts import PromptTemplate
# You are an AI chatbot having a conversation with a user, your name is Jo.
# Do not provide any example. Do not provide user message history.
# Use three sentences maximum and keep the answer as concise as possible. Make sure the answer is short and precise.
# After answering the question ask the user if they want to know any more information. 
# Use two to three sentences maximum and keep the answer as short and precise as possible.
# Follow up
hailabs_template = """Greet the user politely, is its a generic conversation. If you don't know the answer, just say that you don't know, don't try to make up an answer.
Write a response in two to three sentences maximum that appropriately completes the request.
Do not provide other questions or answers.

{context}

Question: {question}
Answer in short:"""


PROMPT = PromptTemplate(
    template=hailabs_template, input_variables=["context", "question"]
)


from constants import CHROMA_SETTINGS, CHROMA_MODULAR_SETTINGS

mute_stream=True
hide_source=True

embeddings = HuggingFaceEmbeddings(model_name=embeddings_model_name)

db = Chroma(persist_directory=general_directory, embedding_function=embeddings, client_settings=CHROMA_SETTINGS)
module_db = Chroma(persist_directory=modular_directory, embedding_function=embeddings, client_settings=CHROMA_MODULAR_SETTINGS)
# ef= 10000, M=1000000
# M=8, ef_construction=16

retriever = db.as_retriever(search_kwargs={"k": target_source_chunks})
# retriever = db.as_retriever(search_type="mmr", search_kwargs={"k": 4, 'fetch_k': 40})
# activate/deactivate the streaming StdOut callback for LLMs
callbacks = [] if mute_stream else [StreamingStdOutCallbackHandler()]

if model_type == "LlamaCpp":
    llm = LlamaCpp(
        model_path=model_path,
        n_ctx=model_n_ctx,
        max_tokens=max_tokens,
        n_batch=model_n_batch,
        use_mlock=use_mlock,
        use_mmap=use_mmap,
        temperature=0,
        callbacks=callbacks,
        stop=["Question:", "Explanation:", "User:", "Expected response:"],
        verbose=True
    )
    # streaming=False
elif model_type == "GPT4All":
    pass
    #f16_kv
    # llm = GPT4All(
    #     model=model_path,
    #     # cache=True,
    #     max_tokens=max_tokens, 
    #     backend='gptj',
    #     # n_threads=6,
    #     n_batch=model_n_batch, 
    #     callbacks=callbacks,
    #     use_mlock=True,
    #     stop=["Question:", "Explanation:", "User:", "Expected response:"],
    #     verbose=True
    # )

else:
    raise Exception(f"Model type {model_type} is not supported. Please choose one of the following: LlamaCpp, GPT4All")

chain_type_kwargs = {"prompt": PROMPT}


def main():
    # Parse the command line arguments
    args = parse_arguments()
    qa = qa_load_model(args.mute_stream, args.hide_source)

    # match model_type:
    #     case "LlamaCpp":
    #         llm = LlamaCpp(model_path=model_path, max_tokens=model_n_ctx, n_batch=model_n_batch, callbacks=callbacks, verbose=False)
    #     case "GPT4All":
    #         llm = GPT4All(model=model_path, max_tokens=model_n_ctx, backend='gptj', n_batch=model_n_batch, callbacks=callbacks, verbose=False)
    #     case _default:
    #         # raise exception if model_type is not supported
    #         raise Exception(f"Model type {model_type} is not supported. Please choose one of the following: LlamaCpp, GPT4All")
    
    # Interactive questions and answers
    while True:
        query = input("\nEnter a query: ")
        if query == "exit":
            break
        if query.strip() == "":
            continue

        # Get the answer from the chain
        start = time.time()
        res = qa(query)
        answer, docs = res['result'], [] if args.hide_source else res['source_documents']
        end = time.time()

        # Print the result
        print("\n\n> Question:")
        print(query)
        print(f"\n> Answer (took {round(end - start, 2)} s.):")
        print(answer)

        # Print the relevant sources used for the answer
        for document in docs:
            print("\n> " + document.metadata["source"] + ":")
            print(document.page_content)

def qa_load_model(mute_stream=True, hide_source=True):
    # args = parse_arguments()
    # return_source_documents = not args.hide_source
    # load_qa_chain(llm=llm, )
    qa = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents= hide_source,
        chain_type_kwargs=chain_type_kwargs,
        # memory=memory
    )
    return qa


def get_response_from_qa(model, sentence):
    print(sentence)
    start = time.time()
    # print(memory.load_memory_variables({}))
    # res = model.run(sentence)
    res = model({"query": sentence})
    #res = model({"query": sentence}, return_only_outputs=True)
    end = time.time()
    print(f"\n> Answer (took {round(end - start, 2)} s.):")

    print(res['result'].strip())
    
    prapare = {"result": res['result'].strip()}
    if "source_documents" in res:
        all_sources = []
        for document in res['source_documents']:
            all_sources.append(document.metadata["source"])
            print("\n> " + document.metadata["source"] + ":")

        prapare["sources"] = all_sources
    
    prapare["time"] = str(round(end - start, 2))+".s"
    return prapare


def get_response_for_ai_tutor(message, msglevel, msgpathway, msgmodule, module_name):
    # search = f"Search for the answer in Level: {level}, Pathway: {pathway}, Module: {module}"
    # print(search)
    # Most probably you will find the answer in this paragraph: {additional}
    # This is all information about current module, most probably you will find the answer in this paragraph: {additional}
    ai_tutor_prompt = """You are a helpful and honest assistant. Greet the user politely, is its a generic conversation. If you don't know the answer, just say that you don't know, don't try to make up an answer.
    Write a response in two to three sentences maximum that appropriately completes the request.
    Do not provide other questions, answers, reason or explanation.
    Current module name is '{module_name}'. You may find the response in content related to 'Level: {msglevel}, Pathway: {msgpathway}, Module: {msgmodule}'

    {context}

    Question: {question}
    Answer in short:"""
    
    PROMPT = PromptTemplate(
        template=ai_tutor_prompt, 
        input_variables=["context", "question"],
        partial_variables={"module_name": module_name, "msglevel": msglevel, "msgpathway": msgpathway, "msgmodule": msgmodule}
        # partial_variables={"additional": "Level: 1, Pathway: 7\nTitle: Pathway7- Refresh Scratch\nDescription: It is time to get hands-on with Scratch!\nLearnig Objectives: An Introduction to Scratch programming\nLevel: 1, Pathway: 7, Module: 2\nTitle: 2:Let us Repeat\nDescription: Repeat\nText\nModule 2:Let us Repeat\nRepeat\nProject Title: Let us Repeat\nlet us repeat scratch project\nCorrect the jumbled scratch blocks\nThis project helps you understand the purpose of a 'repeat loop',  to repeat a task in a loop.\ncorrect the order of the blocks\nOnce you submit the project, please look for notifications for feedback and score"}
    )
    chain_type_kwargs = {"prompt": PROMPT}

    associated_file = os.path.join("modular_documents", f"level_{msglevel}_{msgpathway}_{msgmodule}.txt")
    try:
        filter_retriever = module_db.as_retriever(search_type="mmr", search_kwargs={'k': 2, 'filter': {'source': associated_file}})
        # "k": target_source_chunks, ef= 10000, M=1000000

        start = time.time()
        model = RetrievalQA.from_chain_type(
            llm=llm,
            chain_type="stuff",
            retriever=MergerRetriever(retrievers= [filter_retriever, retriever]),
            return_source_documents= hide_source,
            chain_type_kwargs=chain_type_kwargs,
        )
    except RuntimeError:
        filter_retriever = module_db.as_retriever(search_kwargs={'filter': {'source': associated_file}})

        start = time.time()
        model = RetrievalQA.from_chain_type(
            llm=llm,
            chain_type="stuff",
            retriever=MergerRetriever(retrievers= [filter_retriever, retriever]),
            return_source_documents= hide_source,
            chain_type_kwargs=chain_type_kwargs,
        )
    
    # message = message + f". Current module name is '{module_name}'. You may find the response in content related to 'Level: {msglevel}, Pathway: {msgpathway}, Module: {msgmodule}'"
    print(message)
    res = model({"query": message})# , "level": msglevel, "pathway": msgpathway, "module": msgmodule
    end = time.time()
    res["time"] = str(round(end - start, 2))+".s"
    print(res, type(res))
    return res


def parse_arguments():
    parser = argparse.ArgumentParser(description='privateGPT: Ask questions to your documents without an internet connection, '
                                                 'using the power of LLMs.')
    parser.add_argument("--hide-source", "-S", action='store_true',
                        help='Use this flag to disable printing of source documents used for answers.')

    parser.add_argument("--mute-stream", "-M",
                        action='store_true',
                        help='Use this flag to disable the streaming StdOut callback for LLMs.')

    parser.add_argument("--platform", "-p",
                        action='store_true',
                        help='Select the platform: localhost/stage/prod.')

    return parser.parse_args()


if __name__ == "__main__":
    main()
    # refer_check()
