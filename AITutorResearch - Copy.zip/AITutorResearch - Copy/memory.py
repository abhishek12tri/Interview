from langchain.memory import MongoDBChatMessageHistory

# connection_string: str,
# session_id: str,
# database_name: str = DEFAULT_DBNAME,
# collection_name

if __name__ == "__main__":
    mongo_uri = "mongodb://localhost:27017/"
    db = "chatmongo"
    session_id= "001"
    collection_name = "conv"
    message_history  = MongoDBChatMessageHistory(
        connection_string=mongo_uri,
        session_id=session_id,
        database_name=db, 
        collection_name=collection_name
    )

    print(message_history)
    print(message_history.messages)
    print("message_history")

    # message_history.add_user_message("hi!")
    # message_history.add_ai_message("whats up?")



